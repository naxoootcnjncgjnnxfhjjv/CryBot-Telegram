/**
 * Decision engine for whether to accept an NFT offer. The function
 * encapsulates the rules described in the requirement: accept if the
 * offered price is at least the configured minimum and within the floor
 * minus delta threshold. Additional logic (e.g. stop‑loss on floor drop)
 * could be added here.
 */

export interface DecisionContext {
  /** Floor price in TON for the NFT's collection. */
  floorTon: number;
  /** The offer price in TON. */
  offerTon: number;
  /** Minimum acceptable offer in TON. */
  minTon: number;
  /** Allowed delta percentage from the floor (0‑100). */
  deltaPercent: number;
}

export function shouldAccept(ctx: DecisionContext): boolean {
  // Always enforce a non‑negative floor and delta
  const floor = Math.max(ctx.floorTon, 0);
  const deltaMultiplier = 1 - ctx.deltaPercent / 100;
  const threshold = Math.max(ctx.minTon, floor * deltaMultiplier);
  return ctx.offerTon >= threshold;
}
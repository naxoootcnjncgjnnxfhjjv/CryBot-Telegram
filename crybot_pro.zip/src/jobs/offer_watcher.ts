/**
 * Periodic job for scanning incoming offers and automatically accepting
 * those that meet the configured criteria. This module exposes a single
 * function to start the watcher. Callers can supply a callback to
 * receive notifications of accepted or rejected offers (for example to
 * send a Telegram message).
 */

import { loadConfig } from '../core/config.js';
import { getCollectionFloor, getIncomingOffers, Offer } from '../markets/getgems.js';
import { shouldAccept } from '../rules/decider.js';
import { acceptOffer } from '../ton/tx.js';
import { isOffCooldown, markAccepted } from '../core/state.js';

// Polling interval in milliseconds. Adjust according to how quickly you
// expect new offers to arrive. A shorter interval results in faster
// reaction time but increases API load.
const POLL_INTERVAL_MS = 30_000;

export type Notifier = (msg: string) => Promise<void> | void;

/**
 * Start the offer watcher. The returned timer can be cleared to stop
 * watching. The notifier callback will be invoked whenever an offer is
 * accepted or rejected. It receives a human‑readable message describing
 * the action taken.
 */
export function startOfferWatcher(notify: Notifier): NodeJS.Timer {
  const timer = setInterval(async () => {
    try {
      const cfg = await loadConfig();
      if (!cfg.enabled) {
        // Auto‑accept disabled; nothing to do.
        return;
      }
      for (const collection of cfg.allowList) {
        // Skip collections that are explicitly denied
        if (cfg.denyList.includes(collection)) continue;
        // Get current floor price for the collection
        const floor = await getCollectionFloor(collection);
        // Get incoming offers
        const offers = await getIncomingOffers(collection);
        for (const offer of offers) {
          // Ensure we are off cooldown for this NFT
          if (!isOffCooldown(collection, offer.tokenId)) {
            continue;
          }
          const accept = shouldAccept({
            floorTon: floor,
            offerTon: offer.priceTon,
            minTon: cfg.minTon,
            deltaPercent: cfg.floorDeltaPercent
          });
          if (accept) {
            const result = await acceptOffer({
              collection: offer.collection,
              tokenId: offer.tokenId,
              from: offer.from,
              priceTon: offer.priceTon
            });
            if (result.success) {
              markAccepted(collection, offer.tokenId);
              await notify(`✅ Accepted offer on ${collection} #${offer.tokenId} for ${offer.priceTon} TON.`);
            } else {
              await notify(`⚠️ Failed to accept offer on ${collection} #${offer.tokenId}.`);
            }
          } else {
            await notify(`❌ Rejected offer on ${collection} #${offer.tokenId} ` +
              `for ${offer.priceTon} TON (floor ${floor} TON).`);
          }
        }
      }
    } catch (err) {
      console.error(err);
      await notify('Error while processing offers: ' + (err as Error).message);
    }
  }, POLL_INTERVAL_MS);
  return timer;
}
/**
 * Periodic job for automatically claiming accrued rewards. In many DeFi
 * applications rewards must be manually claimed; this watcher calls the
 * claimRewards stub periodically whenever the auto‑claim feature is
 * enabled. In production you would integrate with the specific protocol
 * contracts to claim pending rewards or staking emissions.
 */

import { loadConfig } from '../core/config.js';
import { claimRewards } from '../ton/tx.js';
import type { Notifier } from './offer_watcher.js';

// Polling interval for auto claim (e.g. every 5 minutes)
const POLL_INTERVAL_MS = 300_000;

export function startAutoClaimWatcher(notify: Notifier): NodeJS.Timer {
  const timer = setInterval(async () => {
    try {
      const cfg = await loadConfig();
      if (!cfg.autoClaimEnabled) {
        return;
      }
      const result = await claimRewards();
      if (result.success) {
        await notify('💰 Claimed pending rewards successfully.');
      } else {
        await notify('⚠️ Failed to claim rewards: ' + (result.error ?? 'unknown error'));
      }
    } catch (err) {
      console.error(err);
      await notify('Error during auto claim: ' + (err as Error).message);
    }
  }, POLL_INTERVAL_MS);
  return timer;
}
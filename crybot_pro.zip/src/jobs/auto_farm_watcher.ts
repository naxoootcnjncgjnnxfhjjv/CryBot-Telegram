/**
 * Periodic job for automatically farming available funds. Farming refers
 * here to depositing idle tokens into yield farms or liquidity pools to
 * earn passive income. This watcher periodically invokes the stubbed
 * farmTokens function to simulate depositing funds. In a real
 * implementation you would integrate with DeFi protocols.
 */

import { loadConfig } from '../core/config.js';
import { farmTokens } from '../ton/tx.js';
import type { Notifier } from './offer_watcher.js';

// Polling interval for auto farming (e.g. every 2 minutes)
const POLL_INTERVAL_MS = 120_000;

export function startAutoFarmWatcher(notify: Notifier): NodeJS.Timer {
  const timer = setInterval(async () => {
    try {
      const cfg = await loadConfig();
      if (!cfg.autoFarmEnabled) {
        return;
      }
      const result = await farmTokens();
      if (result.success) {
        await notify('🌾 Farmed available TON tokens for yield.');
      } else {
        await notify('⚠️ Failed to farm tokens: ' + (result.error ?? 'unknown error'));
      }
    } catch (err) {
      console.error(err);
      await notify('Error during auto farming: ' + (err as Error).message);
    }
  }, POLL_INTERVAL_MS);
  return timer;
}
/**
 * Periodic job for automatically listing NFTs for sale based on the current
 * floor price of each collection. This watcher is a companion to the
 * auto‑accept logic: whereas auto‑accept buys at a discount to the floor,
 * auto‑sale lists your own NFTs at a premium above the floor to
 * opportunistically capture upside.
 *
 * The implementation here is intentionally simplistic. In a real system
 * you might integrate with a marketplace SDK, expose configuration for
 * pricing strategy (e.g. list at floor + 5 %), and track which tokens are
 * already listed. For demonstration purposes we list all allowed
 * collections at 10 % above the current floor.
 */

import { loadConfig } from '../core/config.js';
import { getCollectionFloor } from '../markets/getgems.js';
import { listForSale } from '../ton/tx.js';
import type { Notifier } from './offer_watcher.js';

// Polling interval for auto sales in milliseconds. Adjust as needed.
const POLL_INTERVAL_MS = 60_000;

export function startAutoSaleWatcher(notify: Notifier): NodeJS.Timer {
  const timer = setInterval(async () => {
    try {
      const cfg = await loadConfig();
      if (!cfg.autoSaleEnabled) {
        return;
      }
      for (const collection of cfg.allowList) {
        // Skip explicitly denied collections
        if (cfg.denyList.includes(collection)) continue;
        // Fetch the current floor price
        const floor = await getCollectionFloor(collection);
        // Determine a sale price 10% above the floor
        const salePrice = parseFloat((floor * 1.1).toFixed(2));
        const result = await listForSale({ collection, priceTon: salePrice });
        if (result.success) {
          await notify(`📈 Listed NFTs in ${collection} for sale at ${salePrice} TON.`);
        } else {
          await notify(`⚠️ Failed to list NFTs in ${collection} for sale.`);
        }
      }
    } catch (err) {
      console.error(err);
      await notify('Error during auto sale: ' + (err as Error).message);
    }
  }, POLL_INTERVAL_MS);
  return timer;
}
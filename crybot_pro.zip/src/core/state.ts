/**
 * Runtime state for the offer watcher. This module tracks the last time an
 * offer was accepted for each token to enforce a cooldown. The state is
 * purely in‑memory: if the process restarts the cooldowns reset. If
 * persistent cooldowns are required they should be stored in a database or
 * persisted alongside the config file.
 */

import dayjs from 'dayjs';

// Minimum time between accepts in minutes. In a real implementation this
// should be configurable. We hard‑code a safe default here.
const COOLDOWN_MINUTES = 5;

/**
 * Internal map of NFT unique identifiers to timestamps of the last accepted
 * offer. We key by a combination of collection and token ID to uniquely
 * identify each NFT.
 */
const lastAcceptedAt: Record<string, number> = {};

/**
 * Generate a unique key for an NFT given its collection address and token
 * identifier. This avoids accidental collisions between tokens in different
 * collections.
 */
function keyForToken(collection: string, tokenId: string | number): string {
  return `${collection}:${tokenId}`;
}

/**
 * Determine whether the cooldown has elapsed for a given token. Returns
 * `true` if no accept has happened in the last `COOLDOWN_MINUTES` minutes.
 */
export function isOffCooldown(collection: string, tokenId: string | number): boolean {
  const key = keyForToken(collection, tokenId);
  const last = lastAcceptedAt[key];
  if (!last) return true;
  const diffMinutes = dayjs().diff(dayjs(last), 'minute');
  return diffMinutes >= COOLDOWN_MINUTES;
}

/**
 * Record an acceptance for the given token. Overwrites any existing
 * timestamp. Should be called after a successful accept to enforce the
 * cooldown.
 */
export function markAccepted(collection: string, tokenId: string | number): void {
  const key = keyForToken(collection, tokenId);
  lastAcceptedAt[key] = Date.now();
}
/**
 * Core configuration for the auto‐accept feature.
 *
 * This module exposes a simple configuration store backed by JSON on disk.
 * It allows callers to read and update values such as the floor delta,
 * minimum TON threshold and allow/deny lists for collections. In a real
 * deployment you might instead persist this in a database or a key/value
 * store, but for simplicity we use a local file. The API is promise based
 * because file IO is asynchronous.
 */

import { promises as fs } from 'fs';
import path from 'path';

export interface Config {
  /**
   * Percentage below the collection floor price at which offers will be
   * automatically accepted. For example, a value of 25 means offers down to
   * floor −25 % are accepted. Must be between 0 and 100.
   */
  floorDeltaPercent: number;
  /** Minimum acceptable offer in TON. Offers below this value are always rejected. */
  minTon: number;
  /** Toggle for auto accepting offers. When false no offers are accepted. */
  enabled: boolean;
  /** List of collection addresses from which we will consider offers. */
  allowList: string[];
  /** List of collection addresses we never auto accept for. */
  denyList: string[];

  /**
   * Flag to enable automatic selling of NFTs once certain conditions are met.
   * When true the bot will periodically list eligible NFTs for sale according
   * to the strategy defined in the auto‑sale watcher. Disabled by default.
   */
  autoSaleEnabled: boolean;

  /**
   * Flag to enable automatic farming of rewards on supported platforms. When
   * enabled the bot will periodically deposit idle funds into yield farms
   * using a stubbed implementation. Disabled by default.
   */
  autoFarmEnabled: boolean;

  /**
   * Flag to enable automatic claiming of accumulated rewards from farms or
   * staking contracts. When enabled the bot will periodically claim any
   * pending rewards. Disabled by default.
   */
  autoClaimEnabled: boolean;
}

// Path to where the config JSON is stored. We use process.cwd() so the
// application can be executed from any directory and still find its config.
const CONFIG_PATH = path.join(process.cwd(), 'config.json');

// Default values for the config. These sensible defaults ensure the bot
// behaves safely out of the box and must be explicitly enabled by the user.
const DEFAULT_CONFIG: Config = {
  floorDeltaPercent: 25,
  minTon: 10,
  enabled: false,
  allowList: [],
  denyList: []
  ,
  // New automation toggles default to false for safety. Users must
  // explicitly enable these features via bot commands. See the README
  // for details on how each automation works.
  autoSaleEnabled: false,
  autoFarmEnabled: false,
  autoClaimEnabled: false
};

/**
 * Load the configuration from disk. If no file exists it will be created
 * using {@link DEFAULT_CONFIG}. The returned object is cloned to avoid
 * accidental mutation of in‑memory defaults.
 */
export async function loadConfig(): Promise<Config> {
  try {
    const raw = await fs.readFile(CONFIG_PATH, 'utf8');
    const cfg = JSON.parse(raw) as Config;
    return { ...DEFAULT_CONFIG, ...cfg };
  } catch (err) {
    // If the file does not exist write out the defaults and return them.
    await saveConfig(DEFAULT_CONFIG);
    return { ...DEFAULT_CONFIG };
  }
}

/**
 * Persist the configuration to disk. The entire object is written each
 * time to keep the file human readable. The function resolves once the
 * file has been written.
 */
export async function saveConfig(cfg: Config): Promise<void> {
  const json = JSON.stringify(cfg, null, 2);
  await fs.writeFile(CONFIG_PATH, json, 'utf8');
}

/**
 * Helper for updating a single property on the config. It loads the
 * existing config, updates the value then saves and returns the new config.
 */
async function updateProperty<K extends keyof Config>(key: K, value: Config[K]): Promise<Config> {
  const cfg = await loadConfig();
  (cfg[key] as Config[K]) = value;
  await saveConfig(cfg);
  return cfg;
}

export async function setFloorDeltaPercent(percent: number): Promise<Config> {
  if (percent < 0 || percent > 100) {
    throw new Error('floorDeltaPercent must be between 0 and 100');
  }
  return updateProperty('floorDeltaPercent', percent);
}

export async function setMinTon(minTon: number): Promise<Config> {
  if (minTon < 0) {
    throw new Error('minTon must be non‑negative');
  }
  return updateProperty('minTon', minTon);
}

export async function toggleEnabled(): Promise<Config> {
  const cfg = await loadConfig();
  return updateProperty('enabled', !cfg.enabled);
}

/**
 * Toggle the automatic sale feature. When enabled the auto‑sale watcher
 * will list NFTs for sale according to the configured strategy.
 */
export async function toggleAutoSale(): Promise<Config> {
  const cfg = await loadConfig();
  return updateProperty('autoSaleEnabled', !cfg.autoSaleEnabled);
}

/**
 * Toggle the automatic farming feature. When enabled the auto‑farm watcher
 * will deposit available funds into yield farms.
 */
export async function toggleAutoFarm(): Promise<Config> {
  const cfg = await loadConfig();
  return updateProperty('autoFarmEnabled', !cfg.autoFarmEnabled);
}

/**
 * Toggle the automatic claim feature. When enabled the auto‑claim watcher
 * will claim pending rewards from farms or staking contracts.
 */
export async function toggleAutoClaim(): Promise<Config> {
  const cfg = await loadConfig();
  return updateProperty('autoClaimEnabled', !cfg.autoClaimEnabled);
}

export async function allowCollection(addr: string): Promise<Config> {
  const cfg = await loadConfig();
  if (!cfg.allowList.includes(addr)) cfg.allowList.push(addr);
  // Remove from deny list if present
  cfg.denyList = cfg.denyList.filter(a => a !== addr);
  await saveConfig(cfg);
  return cfg;
}

export async function denyCollection(addr: string): Promise<Config> {
  const cfg = await loadConfig();
  if (!cfg.denyList.includes(addr)) cfg.denyList.push(addr);
  cfg.allowList = cfg.allowList.filter(a => a !== addr);
  await saveConfig(cfg);
  return cfg;
}

export { CONFIG_PATH, DEFAULT_CONFIG };
/**
 * GetGems market interactions.
 *
 * In a real implementation these functions would call the GetGems API or
 * perform web scraping to discover the current floor price for each
 * collection and fetch incoming offers on the user's NFTs. To keep the
 * example self‑contained we provide stubs that return mock data. Replace
 * these implementations with actual API calls as necessary.
 */

import axios from 'axios';

export interface Offer {
  collection: string;
  tokenId: string;
  from: string;
  priceTon: number;
}

/**
 * Fetch the current floor price for a collection in TON. This stub returns
 * a random value between 1 and 50 TON to simulate market fluctuations. In
 * production you would query GetGems or Ton API to obtain the actual
 * floor price.
 */
export async function getCollectionFloor(collectionAddress: string): Promise<number> {
  // TODO: replace with actual API call to get floor price
  // For now return a pseudo‑random floor between 10 and 50 TON
  const base = 10 + Math.random() * 40;
  return parseFloat(base.toFixed(2));
}

/**
 * Fetch incoming offers for NFTs in a specific collection. The stub
 * generates a few random offers with random prices and token IDs. In a
 * real implementation you would call the GetGems API to retrieve offers
 * directed at your account. Only offers for NFTs you own should be
 * considered.
 */
export async function getIncomingOffers(collectionAddress: string): Promise<Offer[]> {
  // TODO: replace with API call to fetch offers for the user's NFTs
  const offers: Offer[] = [];
  const offerCount = Math.floor(Math.random() * 3); // up to 2 offers
  for (let i = 0; i < offerCount; i++) {
    offers.push({
      collection: collectionAddress,
      tokenId: `${Math.floor(Math.random() * 1000)}`,
      from: `user${Math.floor(Math.random() * 100000)}`,
      priceTon: parseFloat((5 + Math.random() * 45).toFixed(2))
    });
  }
  return offers;
}
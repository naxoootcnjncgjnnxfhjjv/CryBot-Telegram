/**
 * Telegram bot command handlers.
 *
 * This module attaches a set of slash commands to a Telegraf bot instance.
 * Each command manipulates the auto‑accept configuration or reports the
 * current state. It relies on functions defined in the core/config
 * module for persistence.
 */

import { Telegraf, Context as TelegrafContext } from 'telegraf';
import {
  loadConfig,
  setFloorDeltaPercent,
  setMinTon,
  toggleEnabled,
  allowCollection,
  denyCollection
  ,
  toggleAutoSale,
  toggleAutoFarm,
  toggleAutoClaim
} from '../core/config.js';

/**
 * Attach command handlers to a bot. Must be called once after the bot is
 * instantiated. Each handler returns a promise; errors are caught and
 * reported to the user.
 */
export function registerCommands(bot: Telegraf<TelegrafContext>): void {
  bot.command('toggle_autoaccept', async ctx => {
    try {
      const cfg = await toggleEnabled();
      await ctx.reply(`Auto‑accept is now ${cfg.enabled ? 'enabled' : 'disabled'}.`);
    } catch (e) {
      console.error(e);
      await ctx.reply('Failed to toggle auto‑accept.');
    }
  });

  bot.command('floor_delta', async ctx => {
    const [, arg] = ctx.message.text.split(/\s+/);
    const value = parseFloat(arg);
    if (isNaN(value)) {
      return ctx.reply('Usage: /floor_delta <percent>');
    }
    try {
      const cfg = await setFloorDeltaPercent(value);
      await ctx.reply(`Floor delta set to ${cfg.floorDeltaPercent}%`);
    } catch (e) {
      console.error(e);
      await ctx.reply('Error updating floor delta: ' + (e as Error).message);
    }
  });

  bot.command('min_ton', async ctx => {
    const [, arg] = ctx.message.text.split(/\s+/);
    const value = parseFloat(arg);
    if (isNaN(value)) {
      return ctx.reply('Usage: /min_ton <amount>');
    }
    try {
      const cfg = await setMinTon(value);
      await ctx.reply(`Minimum TON set to ${cfg.minTon}`);
    } catch (e) {
      console.error(e);
      await ctx.reply('Error updating minimum TON: ' + (e as Error).message);
    }
  });

  bot.command('allow', async ctx => {
    const [, addr] = ctx.message.text.split(/\s+/);
    if (!addr) {
      return ctx.reply('Usage: /allow <collection address>');
    }
    try {
      const cfg = await allowCollection(addr);
      await ctx.reply(`Collection ${addr} allowed. Now allowed: ${cfg.allowList.join(', ') || 'none'}.`);
    } catch (e) {
      console.error(e);
      await ctx.reply('Error allowing collection: ' + (e as Error).message);
    }
  });

  bot.command('deny', async ctx => {
    const [, addr] = ctx.message.text.split(/\s+/);
    if (!addr) {
      return ctx.reply('Usage: /deny <collection address>');
    }
    try {
      const cfg = await denyCollection(addr);
      await ctx.reply(`Collection ${addr} denied. Now denied: ${cfg.denyList.join(', ') || 'none'}.`);
    } catch (e) {
      console.error(e);
      await ctx.reply('Error denying collection: ' + (e as Error).message);
    }
  });

  bot.command('status', async ctx => {
    try {
      const cfg = await loadConfig();
      const status = `Auto‑accept: ${cfg.enabled ? 'ON' : 'OFF'}\n` +
        `Floor delta: ${cfg.floorDeltaPercent}%\n` +
        `Minimum TON: ${cfg.minTon}\n` +
        `Allow list: ${cfg.allowList.join(', ') || 'none'}\n` +
        `Deny list: ${cfg.denyList.join(', ') || 'none'}\n` +
        `Auto‑sale: ${cfg.autoSaleEnabled ? 'ON' : 'OFF'}\n` +
        `Auto‑farm: ${cfg.autoFarmEnabled ? 'ON' : 'OFF'}\n` +
        `Auto‑claim: ${cfg.autoClaimEnabled ? 'ON' : 'OFF'}`;
      await ctx.reply(status);
    } catch (e) {
      console.error(e);
      await ctx.reply('Error retrieving status');
    }
  });

  // Toggle auto sale automation
  bot.command('toggle_autosale', async ctx => {
    try {
      const cfg = await toggleAutoSale();
      await ctx.reply(`Auto‑sale is now ${cfg.autoSaleEnabled ? 'enabled' : 'disabled'}.`);
    } catch (e) {
      console.error(e);
      await ctx.reply('Failed to toggle auto sale.');
    }
  });

  // Toggle auto farming automation
  bot.command('toggle_autofarm', async ctx => {
    try {
      const cfg = await toggleAutoFarm();
      await ctx.reply(`Auto‑farm is now ${cfg.autoFarmEnabled ? 'enabled' : 'disabled'}.`);
    } catch (e) {
      console.error(e);
      await ctx.reply('Failed to toggle auto farm.');
    }
  });

  // Toggle auto claim automation
  bot.command('toggle_autoclaim', async ctx => {
    try {
      const cfg = await toggleAutoClaim();
      await ctx.reply(`Auto‑claim is now ${cfg.autoClaimEnabled ? 'enabled' : 'disabled'}.`);
    } catch (e) {
      console.error(e);
      await ctx.reply('Failed to toggle auto claim.');
    }
  });
}
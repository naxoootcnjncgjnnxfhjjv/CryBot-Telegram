/**
 * Entry point for the auto‑accept bot. This script starts a Telegram bot
 * using Telegraf, registers command handlers and launches the offer
 * watcher. All configuration is loaded from environment variables and
 * stored persistently in the config.json file.
 */

import { Telegraf } from 'telegraf';
import { registerCommands } from './bot/commands.js';
import { startOfferWatcher } from './jobs/offer_watcher.js';
import { startAutoSaleWatcher } from './jobs/auto_sale_watcher.js';
import { startAutoFarmWatcher } from './jobs/auto_farm_watcher.js';
import { startAutoClaimWatcher } from './jobs/auto_claim_watcher.js';

const botToken = process.env.BOT_TOKEN;
if (!botToken) {
  throw new Error('BOT_TOKEN environment variable must be set');
}

// Optional: chat ID to send notifications to. If not provided the bot
// will not send notifications outside of command responses.
const adminChatId = process.env.ADMIN_CHAT_ID;

const bot = new Telegraf(botToken);

// Register slash command handlers
registerCommands(bot);

// Launch the bot
bot.launch().then(() => {
  console.log('Telegram bot started');
});

// Start watching offers with a notifier that sends messages to the admin
const notifier = async (msg: string) => {
  if (adminChatId) {
    try {
      await bot.telegram.sendMessage(adminChatId, msg);
    } catch (err) {
      console.error('Failed to send Telegram notification', err);
    }
  }
  console.log(msg);
};

startOfferWatcher(notifier);

// Start the additional automation watchers. These timers will no‑op when
// their respective features are disabled in the config. They reuse the
// same notifier to send status messages via Telegram and console.
startAutoSaleWatcher(notifier);
startAutoFarmWatcher(notifier);
startAutoClaimWatcher(notifier);

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
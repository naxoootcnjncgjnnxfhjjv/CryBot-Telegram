# CryBot Telegram – Pro Edition

This repository contains a modernised version of the original CryBot
Telegram integration. The bot has been rewritten in TypeScript with a
modular architecture and now supports several advanced automation
features on top of the original auto‑accept functionality:

* **Auto‑accept** – Automatically accept offers on your NFTs when the
  offer price meets or exceeds a configurable percentage below the
  current floor price and is above a minimum TON threshold.
* **Auto‑sale** – Periodically list your NFTs for sale at a premium
  above the collection floor (default 10 %). This feature can be
  enabled or disabled on demand via `/toggle_autosale`.
* **Auto‑farm** – Deposit idle funds into a yield farm to earn
  passive rewards. This is a stubbed implementation that simulates
  farming; integrate with your preferred DeFi protocol to make it
  functional.
* **Auto‑claim** – Claim accumulated rewards from farms or staking
  contracts. As with farming, the implementation here is a stub and
  should be replaced with real calls to your reward contracts.

## Commands

The bot exposes the following Telegram slash commands:

| Command | Description |
| --- | --- |
| `/toggle_autoaccept` | Enable/disable auto‑accepting offers |
| `/floor_delta <percent>` | Set percentage below floor to accept |
| `/min_ton <amount>` | Set minimum acceptable price in TON |
| `/allow <collection>` | Add a collection to the allow‑list |
| `/deny <collection>` | Add a collection to the deny‑list |
| `/status` | Show current configuration and automation statuses |
| `/toggle_autosale` | Enable/disable auto‑sale feature |
| `/toggle_autofarm` | Enable/disable auto‑farm feature |
| `/toggle_autoclaim` | Enable/disable auto‑claim feature |

Configuration is persisted in `config.json` in the working directory.
The first run will create this file with sensible defaults. You can
edit it manually or use the commands above to update values.

## Running the Bot

Install dependencies and run the bot with Node.js 18 or later:

```bash
npm install
npm run build
npm start
```

Environment variables:

* `BOT_TOKEN` – Telegram bot token.
* `ADMIN_CHAT_ID` (optional) – Telegram chat ID to receive
  notifications.
* `TON_MNEMONIC` – Comma separated mnemonic phrase for your TON
  wallet. **Keep this secret!**

## Extending the Stubs

This repository uses stub implementations for market interactions and
DeFi protocol calls (see `src/markets/getgems.ts` and `src/ton/tx.ts`).
To make the bot fully functional you will need to replace these
stubs with real API integrations:

* Replace the random floor and offer generation with calls to
  GetGems or Ton API to fetch floor prices and incoming offers.
* Implement `listForSale`, `farmTokens` and `claimRewards` to interact
  with your chosen marketplace and farming contracts.

Contributions and pull requests are welcome!